package com.example.b07finalproject.ui.complaint;

import androidx.lifecycle.ViewModel;

public class ComplaintViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}