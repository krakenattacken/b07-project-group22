package com.example.b07finalproject.ui.announcements;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.fragment.app.Fragment;

import com.example.b07finalproject.DBDependent;
import com.example.b07finalproject.R;
import com.example.b07finalproject.databinding.FragmentPostAnnounBinding;
import com.example.b07finalproject.mainViewModel;

import java.util.List;


public class PostAnnounFragment extends Fragment implements DBDependent {

    String title;
    String location;
    String description;

    EditText titleInput;
    EditText locationInput;
    EditText descriptionInput;

    Button postButton;
    private FragmentPostAnnounBinding binding;

    private DBDependent db;

    private mainViewModel viewModel;

    public static PostAnnounFragment newInstance() {
        return new PostAnnounFragment();
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentPostAnnounBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        View titleV = requireActivity().findViewById(R.id.titleInput);
        View locationV = requireActivity().findViewById(R.id.locationInput);
        View descriptionV = requireActivity().findViewById(R.id.descriptionInput);


        titleInput = (EditText)titleV.findViewById(R.id.titleInput);
        locationInput = (EditText)locationV.findViewById(R.id.locationInput);
        descriptionInput = (EditText)descriptionV.findViewById(R.id.descriptionInput);

        //postButton = (Button)postV.findViewById(R.id.postButton);


        //Post Button in fragment_post_announ_xml should send notifications to observers (students) and take admin back to AnnouncementsFragment page
        //with the new posted announcement at the top
        binding.postButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //These inputs should be in the database
                title = titleInput.getText().toString();
                location = locationInput.getText().toString();
                description = descriptionInput.getText().toString();

                //viewModel.addToDB(title, "announcement", title+location, this);

                NavHostFragment.findNavController(PostAnnounFragment.this)
                        .navigate(R.id.action_nav_postannoun_to_nav_announcements);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    @Override
    public void loadDataFromDB(Object[] items) {

    }

    @Override
    public void onDBFail(String reason) {

    }
}

