package com.example.b07finalproject.ui.events;

public interface OnItemClickListener {
    void onItemClick(int position);
}
