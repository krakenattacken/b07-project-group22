package com.example.b07finalproject.ui.announcements;

public interface OnItemClickListener {
    void onItemClick(int position);
}
