package com.example.b07finalproject.ui.login;

public class Admin extends User{
    public Admin(){
        super();
    }

    public Admin(String username, String password){
        super(username, password);
    }
}
