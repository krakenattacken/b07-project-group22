package com.example.b07finalproject.ui.postChecker;

public class GradeException extends RuntimeException{
    public GradeException(String message) {
        super(message);
    }
}
