package com.example.b07finalproject.ui.postChecker;

public interface GradeToGPA {
    // interface so can be reused in case the conversion changes
    double toGPA(int grade);
}
